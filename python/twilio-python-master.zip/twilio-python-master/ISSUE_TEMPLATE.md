*Note: These issues are for bugs and feature requests for the helper libraries.
If you need help or support, please email help@twilio.com and one of our experts
will assist you!*


**Version:**

### Code Snippet
```python
# paste code here
```

### Exception/Log
```
<place exception/log here>
```

### Steps to Reproduce
1.
2.
3.


### Feature Request
_If this is a feature request, make sure you search Issues for an existing
request before creating a new one!_